<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Lab 7</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>9731a50a-0b93-4aa2-93f1-e6a5eccffa73</testSuiteGuid>
   <testCaseLink>
      <guid>985dea55-ee66-4b78-9f9a-d82dfd5ad112</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Lab 7/Access Blog</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>96fdca80-379d-4dee-b858-514becab31c7</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Lab 7/View blog detail</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>f1cc1f76-a8e4-461d-85f2-02c5ce17fc66</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Lab 7/Blog tag</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>8f428ad6-bece-44e2-8420-1d44c1436bea</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Lab 7/blog commentP</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>f1b74c64-e36a-4288-ab72-abd800846eaf</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Lab 7/blog commentNev</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>7469643a-6db9-4f9f-b05b-fe3cace72786</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Lab 7/Access New</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>6c70e696-3c02-4ef6-bfa4-79790f3cfedf</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Lab 7/View New Detail</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>56b5dad3-bff8-4c40-8144-99f108053b15</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Lab 7/newsCommnentP</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>8842bc4b-43e2-40c5-b2bc-8d96eeb4b831</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Lab 7/newsComNev</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
    