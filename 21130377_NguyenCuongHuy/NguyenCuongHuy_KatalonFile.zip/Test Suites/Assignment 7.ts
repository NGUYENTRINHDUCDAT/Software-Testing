<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Assignment 7</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>7bf27354-cbd6-47eb-90a4-d6e51dd58ce4</testSuiteGuid>
   <testCaseLink>
      <guid>a9edbfba-3d52-426f-ae9c-f2c40af14eb5</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Assignment 7/Product Detail & Add to Cart 1</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>9d87d4ed-6523-4512-9ef3-21490fe7e043</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Assignment 7/Product Detail & Add to Cart 2</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>e5e65f4e-9a48-4b93-a1d7-242ec92e6d7c</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Assignment 7/Product Detail & Add to Cart 3</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>0bf94dc4-d963-4965-8c18-0121043fde03</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Assignment 7/Product Detail & Add to Cart 4</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>9e70d578-a9b5-42c3-a581-d1c0d0978c24</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Assignment 7/Product Detail & Add to Cart 5</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>4623d6d5-6bda-4903-b49d-9e18fa597eea</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Assignment 7/Product Detail & Add to Cart 6</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>f0833c64-c62a-4f89-a1f0-c1506daee835</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Assignment 7/Product Detail & Add to Cart 7</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
    