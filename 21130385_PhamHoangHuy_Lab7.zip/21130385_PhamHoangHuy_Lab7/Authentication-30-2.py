# -*- coding: utf-8 -*-
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import Select
from selenium.common.exceptions import NoSuchElementException
from selenium.common.exceptions import NoAlertPresentException
import unittest, time, re

class AppDynamicsJob1(unittest.TestCase):
    def setUp(self):
        # AppDynamics will automatically override this web driver
        # as documented in https://docs.appdynamics.com/display/PRO44/Write+Your+First+Script
        self.driver = webdriver.Firefox()
        self.driver.implicitly_wait(30)
        self.base_url = "https://www.google.com/"
        self.verificationErrors = []
        self.accept_next_alert = True
    
    def test_app_dynamics_job(self):
        driver = self.driver
        driver.get("https://demo.nopcommerce.com/register")
        driver.find_element_by_id("gender-male").click()
        driver.find_element_by_id("FirstName").click()
        driver.find_element_by_id("FirstName").clear()
        driver.find_element_by_id("FirstName").send_keys("Test")
        driver.find_element_by_id("LastName").click()
        driver.find_element_by_id("LastName").clear()
        driver.find_element_by_id("LastName").send_keys("Ter")
        driver.find_element_by_id("Email").click()
        driver.find_element_by_id("Email").clear()
        driver.find_element_by_id("Email").send_keys("xyz@gmail.com")
        driver.find_element_by_id("Company").click()
        driver.find_element_by_id("Company").clear()
        driver.find_element_by_id("Company").send_keys("Nong Lam University")
        driver.find_element_by_id("Password").click()
        driver.find_element_by_id("Password").clear()
        driver.find_element_by_id("Password").send_keys("123456")
        driver.find_element_by_id("ConfirmPassword").click()
        driver.find_element_by_id("ConfirmPassword").clear()
        driver.find_element_by_id("ConfirmPassword").send_keys("123456")
        driver.find_element_by_id("register-button").click()
        self.assertEqual("Your registration completed", driver.find_element_by_xpath("//main[@id='main']/div/section/div/div[2]/div").text)
        self.assertEqual("https://demo.nopcommerce.com/", driver.current_url)
    
    def is_element_present(self, how, what):
        try: self.driver.find_element(by=how, value=what)
        except NoSuchElementException as e: return False
        return True
    
    def is_alert_present(self):
        try: self.driver.switch_to_alert()
        except NoAlertPresentException as e: return False
        return True
    
    def close_alert_and_get_its_text(self):
        try:
            alert = self.driver.switch_to_alert()
            alert_text = alert.text
            if self.accept_next_alert:
                alert.accept()
            else:
                alert.dismiss()
            return alert_text
        finally: self.accept_next_alert = True
    
    def tearDown(self):
        # To know more about the difference between verify and assert,
        # visit https://www.seleniumhq.org/docs/06_test_design_considerations.jsp#validating-results
        self.assertEqual([], self.verificationErrors)

if __name__ == "__main__":
    unittest.main()
