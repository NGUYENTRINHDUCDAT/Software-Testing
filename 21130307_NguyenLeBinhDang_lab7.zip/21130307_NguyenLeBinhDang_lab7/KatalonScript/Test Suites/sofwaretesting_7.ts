<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>sofwaretesting_7</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>aa926b02-3655-42c4-931f-0782b89b6b57</testSuiteGuid>
   <testCaseLink>
      <guid>d30466d6-6417-4a8d-808a-21d50755e276</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/sofwaretesting_7/UpdateCart</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>90d4b540-fb15-479d-8e0b-f7cf4e3aceca</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/sofwaretesting_7/CheckOutGuest</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
    