# -*- coding: utf-8 -*-
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import Select
from selenium.common.exceptions import NoSuchElementException
from selenium.common.exceptions import NoAlertPresentException
import unittest, time, re

class TC06ViewWishlistWhileLoggedInWithEmptyWishlist(unittest.TestCase):
    def setUp(self):
        self.driver = webdriver.Chrome(executable_path=r'')
        self.driver.implicitly_wait(30)
        self.base_url = "https://www.google.com/"
        self.verificationErrors = []
        self.accept_next_alert = True
    
    def test_t_c06_view_wishlist_while_logged_in_with_empty_wishlist(self):
        driver = self.driver
        driver.get("https://demo.nopcommerce.com/")
        driver.find_element_by_link_text("Log in").click()
        driver.find_element_by_id("Email").clear()
        driver.find_element_by_id("Email").send_keys("21130381@st.hcmuaf.edu.vn")
        driver.find_element_by_id("Password").clear()
        driver.find_element_by_id("Password").send_keys("nopCommerce.3123")
        driver.find_element_by_xpath("//main[@id='main']/div/section/div/div[2]/div/div[2]/form/div[2]/button").click()
        driver.find_element_by_xpath("(.//*[normalize-space(text()) and normalize-space(.)='Log out'])[1]/following::span[1]").click()
        driver.find_element_by_link_text("Log in").click()
    
    def is_element_present(self, how, what):
        try: self.driver.find_element(by=how, value=what)
        except NoSuchElementException as e: return False
        return True
    
    def is_alert_present(self):
        try: self.driver.switch_to_alert()
        except NoAlertPresentException as e: return False
        return True
    
    def close_alert_and_get_its_text(self):
        try:
            alert = self.driver.switch_to_alert()
            alert_text = alert.text
            if self.accept_next_alert:
                alert.accept()
            else:
                alert.dismiss()
            return alert_text
        finally: self.accept_next_alert = True
    
    def tearDown(self):
        self.driver.quit()
        self.assertEqual([], self.verificationErrors)

if __name__ == "__main__":
    unittest.main()
