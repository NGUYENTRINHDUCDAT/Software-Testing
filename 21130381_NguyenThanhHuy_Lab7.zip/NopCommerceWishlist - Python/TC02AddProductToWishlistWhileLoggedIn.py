# -*- coding: utf-8 -*-
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import Select
from selenium.common.exceptions import NoSuchElementException
from selenium.common.exceptions import NoAlertPresentException
import unittest, time, re

class TC02AddProductToWishlistWhileLoggedIn(unittest.TestCase):
    def setUp(self):
        self.driver = webdriver.Firefox()
        self.driver.implicitly_wait(30)
        self.base_url = "https://www.google.com/"
        self.verificationErrors = []
        self.accept_next_alert = True
    
    def test_t_c02_add_product_to_wishlist_while_logged_in(self):
        driver = self.driver
        driver.get("https://demo.nopcommerce.com/")
        from selenium.webdriver.common.by import By

        driver.find_element(By.LINK_TEXT, "Log in").click()

        driver.find_element(By.ID, "Email").clear()
        driver.find_element(By.ID, "Email").send_keys("21130381@st.hcmuaf.edu.vn")

        driver.find_element(By.ID, "Password").clear()
        driver.find_element(By.ID, "Password").send_keys("nopCommerce.3123")

        driver.find_element(
            By.XPATH,
            "//main[@id='main']/div/section/div/div[2]/div/div[2]/form/div[2]/button"
        ).click()

        driver.find_element(
            By.XPATH,
            "//main[@id='main']/div/section/div/div/section[2]/div/div[3]/article/div[2]/div[3]/div[2]/button[3]"
        ).click()

    def is_element_present(self, how, what):
        try: self.driver.find_element(by=how, value=what)
        except NoSuchElementException as e: return False
        return True
    
    def is_alert_present(self):
        try: self.driver.switch_to_alert()
        except NoAlertPresentException as e: return False
        return True
    
    def close_alert_and_get_its_text(self):
        try:
            alert = self.driver.switch_to_alert()
            alert_text = alert.text
            if self.accept_next_alert:
                alert.accept()
            else:
                alert.dismiss()
            return alert_text
        finally: self.accept_next_alert = True
    
    def tearDown(self):
        self.driver.quit()
        self.assertEqual([], self.verificationErrors)

if __name__ == "__main__":
    unittest.main()
