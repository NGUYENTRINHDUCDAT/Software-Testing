# -*- coding: utf-8 -*-
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import Select
from selenium.common.exceptions import NoSuchElementException
from selenium.common.exceptions import NoAlertPresentException
import unittest, time, re

class TC03AddExistingProductToWishlistAndVerifyQuantityIncrement(unittest.TestCase):
    def setUp(self):
        self.driver = webdriver.Chrome(executable_path='D:\\Downloads\\NopCommerceWishlist\\chromedriver.exe')
        self.driver.implicitly_wait(30)
        self.base_url = "https://www.google.com/"
        self.verificationErrors = []
        self.accept_next_alert = True
    
    def test_t_c03_add_existing_product_to_wishlist_and_verify_quantity_increment(self):
        driver = self.driver
        driver.get("https://demo.nopcommerce.com/")
        driver.find_element_by_xpath("//main[@id='main']/div/section/div/div/section[2]/div/div[3]/article/div[2]/div[3]/div[2]/button[3]").click()
        driver.find_element_by_xpath("//div[@id='bar-notification']/div/span").click()
        driver.find_element_by_xpath("(.//*[normalize-space(text()) and normalize-space(.)='Log out'])[1]/following::span[1]").click()
    
    def is_element_present(self, how, what):
        try: self.driver.find_element(by=how, value=what)
        except NoSuchElementException as e: return False
        return True
    
    def is_alert_present(self):
        try: self.driver.switch_to_alert()
        except NoAlertPresentException as e: return False
        return True
    
    def close_alert_and_get_its_text(self):
        try:
            alert = self.driver.switch_to_alert()
            alert_text = alert.text
            if self.accept_next_alert:
                alert.accept()
            else:
                alert.dismiss()
            return alert_text
        finally: self.accept_next_alert = True
    
    def tearDown(self):
        self.driver.quit()
        self.assertEqual([], self.verificationErrors)

if __name__ == "__main__":
    unittest.main()
